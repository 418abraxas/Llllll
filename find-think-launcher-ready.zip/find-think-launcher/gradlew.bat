@echo off
setlocal
set "GRADLE_VERSION=8.11.1"
set "GRADLE_SHA256=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6"
set "GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_ROOT=%GRADLE_USER_HOME%\find-think-bootstrap"
set "GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java 17 or newer is required. Install a JDK and put java on PATH.
  exit /b 1
)

if not exist "%GRADLE_BIN%" (
  where powershell >nul 2>nul
  if errorlevel 1 (
    echo ERROR: PowerShell is required to download and verify Gradle.
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $root=$env:CACHE_ROOT; New-Item -ItemType Directory -Force -Path $root | Out-Null; $zip=Join-Path $env:TEMP 'find-think-gradle-8.11.1.zip'; Invoke-WebRequest -Uri $env:GRADLE_URL -OutFile $zip; $hash=(Get-FileHash -Algorithm SHA256 $zip).Hash.ToLower(); if ($hash -ne $env:GRADLE_SHA256) { throw 'Gradle distribution checksum mismatch; refusing to install.' }; $tmp=Join-Path $env:TEMP ('find-think-gradle-' + [guid]::NewGuid()); New-Item -ItemType Directory -Path $tmp | Out-Null; Expand-Archive -Path $zip -DestinationPath $tmp -Force; if (Test-Path $env:GRADLE_HOME) { Remove-Item $env:GRADLE_HOME -Recurse -Force }; Move-Item (Join-Path $tmp ('gradle-' + $env:GRADLE_VERSION)) $env:GRADLE_HOME; Remove-Item $tmp -Recurse -Force; Remove-Item $zip -Force"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
