# Architecture

## Invariants
1. **Memory first:** visible screens own transient resources; screen lists, request buffers, dialogs, and payload bytes are cleared when the screen stops or is closed.
2. **Local first:** Find renders local results independently of network state; cloud search is not currently implemented.
3. **Private by default:** the request body contains the current query as the only message content. App labels and chat history are not transmitted.
4. **Minimal surface:** one app module, eight production Kotlin files, two runtime dependencies (AndroidX Core and RecyclerView). `org.json` is test-only; it adds no runtime APK or process-memory cost.
5. **No background work:** no services, receivers, polling, or extra processes. Think's request thread exists only for a user-initiated request and is interrupted/cancelled when Think closes or the activity stops.
6. **User-owned infrastructure:** endpoint, model, and API key are user-provided; no bundled keys, telemetry, accounts, or hosted backend.
7. **Confirmed actions:** only four whitelisted action types are parsed; a valid proposal must be confirmed before dispatch.

## Runtime flow

`MainActivity -> HomeScreen -> Find`

Find discovers launchable activities with `PackageManager`, matches locally, and ranks exact/prefix/word-prefix/substring matches. Launch counts are stored locally and influence ranking. The Home screen uses the Android system wallpaper through a transparent activity window and drops its app list, query and adapter results when leaving the screen.

`MainActivity -> ThinkScreen -> AiClient`

Think sends one user query to a user-configured HTTPS Chat Completions endpoint. Model selection and the streaming flag are transport fields; the only message content is the query. The request uses Bearer authentication and Server-Sent Events. Redirects are disabled so the API key is not forwarded to another host. Request errors are read into a bounded 512-character snippet.

The payload inspector displays a copy of the exact request-body bytes after the request body is written. Those bytes are cleared when Think closes or the activity stops.

## Action proposal protocol

The first version recognizes explicit assistant text markers:

`[[ACTION]]{"type":"set_timer","seconds":300}[[/ACTION]]`

Allowed types: `open_app`, `search_store`, `set_timer`, and `open_url`. Proposals are parsed as JSON, validated independently of the model, and displayed one at a time. The user can confirm the action or cancel the remaining proposals. Unknown and invalid proposals are discarded. This is not provider-native function calling.

## Lifecycle

- `onStart`: refresh launchable app data and render the local query state.
- Switching from Find to Think: clear Find's app list, usage map, query and adapter results.
- Leaving Think: cancel its request, dismiss its dialog, clear transcript/prompt/action queue, and clear last-payload bytes.
- `onStop`: clear screen state, cancel active AI request, clear last-payload bytes, and release the activity's app list.

No background services, receivers, providers, workers, or scheduled jobs are declared.

## Manifest

The manifest declares INTERNET, a MAIN+LAUNCHER `<queries>` entry, and one HOME/DEFAULT/MAIN activity. It does not declare `QUERY_ALL_PACKAGES`, services, receivers, or providers.

## Source map

- `MainActivity.kt`: HOME activity, navigation, app launch, Store hand-off.
- `HomeScreen.kt`: native Find UI and RecyclerView.
- `Find.kt`: discovery and ranking.
- `Think.kt`: transient Think UI, settings and confirmations.
- `AiClient.kt`: HTTPS streaming transport and request-body construction.
- `AiActions.kt`: proposal parsing, allowlist, validation and dispatch.
- `Settings.kt`: local learned usage counts and encrypted AI configuration.
- `Memory.kt`: reserved memory-management boundary; no general cache is implemented.
