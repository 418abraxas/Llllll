# Implementation status

## Phase 0 — Foundation
- [x] Single app module and one HOME activity.
- [x] Native Views and one Find input.
- [x] Manifest contains only INTERNET and MAIN+LAUNCHER visibility query.
- [ ] Device verification and baseline PSS measurement.

## Phase 1 — Find
- [x] PackageManager launcher discovery.
- [x] Local matching and learned launch-count ranking.
- [x] Application launch.
- [x] Play Store search hand-off (market URI with HTTPS fallback).
- [ ] Low-end-device latency benchmark and OEM compatibility verification.

## Think — early implementation
- [x] Think screen and user-configured endpoint/model/API key.
- [x] API key encrypted with Android Keystore AES-GCM.
- [x] HTTPS-only Chat Completions transport with Bearer authentication.
- [x] Streaming SSE reader and cancellation on screen close/activity stop.
- [x] Query-only message content and last-request-body viewer using shared payload construction.
- [x] Redirects disabled; error response snippet bounded to 512 characters.
- [x] Four marker-based action proposals, validation, individual confirmation and local dispatch.
- [ ] Provider-native tool calling and broader provider compatibility.
- [ ] Context-sharing opt-in (not implemented; no context is sent).

## Build setup
- [x] Android Gradle Plugin pinned to 8.9.1.
- [x] Gradle 8.11.1 distribution pinned with official SHA-256 verification.
- [x] Kotlin Gradle Plugin pinned to 2.1.20.
- [x] SDK Platform 35 and Build-Tools 35.0.0 pinned in module build configuration.
- [x] `gradlew` and `gradlew.bat` bootstrap launchers included.
- [ ] Gradle build and unit tests executed in an environment with network access and Android SDK installed.
- [x] Release build is configured for minification/resource shrinking; AGP 8.9.1 uses R8 full mode by default.
- [ ] R8 release build executed and verified.
- [ ] Physical-device testing and PSS measurements.

## Commands

```bash
./gradlew build
```

Windows:

```bat
gradlew.bat build
```

The Android SDK Platform 35 and Build-Tools 35.0.0 must be installed. The bootstrap launcher installs the pinned Gradle distribution but does not install the Android SDK.
