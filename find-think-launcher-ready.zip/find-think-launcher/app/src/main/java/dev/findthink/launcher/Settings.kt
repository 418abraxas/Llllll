package dev.findthink.launcher

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object Settings {
    private const val PREFS = "find_think_local"
    private const val USAGE_PREFIX = "launch_count_"

    fun readUsage(context: Context): Map<String, Int> {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .all
            .mapNotNull { (key, value) ->
                if (!key.startsWith(USAGE_PREFIX) || value !is Int) null
                else key.removePrefix(USAGE_PREFIX) to value
            }.toMap()
    }

    fun recordLaunch(context: Context, packageName: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = USAGE_PREFIX + packageName
        prefs.edit().putInt(key, (prefs.getInt(key, 0) + 1).coerceAtMost(100)).apply()
    }
}

object AiSettings {
    private const val PREFS = "find_think_ai"
    private const val KEY_ALIAS = "find_think_api_key_v1"

    fun read(context: Context): AiConfig {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AiConfig(
            endpoint = prefs.getString("endpoint", "").orEmpty(),
            model = prefs.getString("model", "").orEmpty(),
            apiKey = decrypt(prefs.getString("key_blob", "").orEmpty())
        )
    }

    fun write(context: Context, endpoint: String, model: String, apiKey: String) {
        val encrypted = encrypt(apiKey)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("endpoint", endpoint)
            .putString("model", model)
            .putString("key_blob", encrypted)
            .apply()
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        if (value.isEmpty()) return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + encrypted
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        if (value.isEmpty()) return ""
        return try {
            val combined = Base64.decode(value, Base64.NO_WRAP)
            val iv = combined.copyOfRange(0, 12)
            val encrypted = combined.copyOfRange(12, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }
}
