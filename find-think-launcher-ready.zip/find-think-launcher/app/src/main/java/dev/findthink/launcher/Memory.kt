package dev.findthink.launcher

/**
 * Phase 0/1 has no long-lived in-memory cache.
 * Screen-owned collections are cleared by HomeScreen.clearTransientState().
 */
object Memory {
    fun clearEligibleCaches() {
        // Deliberately empty until a measured, byte-bounded cache is introduced.
    }
}
