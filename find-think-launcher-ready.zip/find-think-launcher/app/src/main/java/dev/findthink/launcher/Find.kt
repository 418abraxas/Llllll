package dev.findthink.launcher

import android.content.Intent
import android.content.pm.PackageManager

data class LaunchableApp(
    val label: String,
    val packageName: String,
    val activityName: String
)

object Find {
    fun loadLaunchableApps(packageManager: PackageManager): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info ->
                val activity = info.activityInfo ?: return@mapNotNull null
                val label = info.loadLabel(packageManager)?.toString()
                    ?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                LaunchableApp(label, activity.packageName, activity.name)
            }
            .distinctBy { it.packageName to it.activityName }
    }

    fun rank(
        query: String,
        apps: List<LaunchableApp>,
        usage: Map<String, Int> = emptyMap()
    ): List<LaunchableApp> {
        val needle = normalize(query)
        if (needle.isEmpty()) return emptyList()

        return apps.asSequence()
            .mapNotNull { app ->
                val label = normalize(app.label)
                val base = when {
                    label == needle -> 1_000
                    label.startsWith(needle) -> 700
                    label.split(Regex("\\s+")).any { it.startsWith(needle) } -> 500
                    label.contains(needle) -> 300
                    else -> return@mapNotNull null
                }
                val learned = (usage[app.packageName] ?: 0).coerceIn(0, 100) * 2
                app to (base + learned)
            }
            .sortedWith(
                compareByDescending<Pair<LaunchableApp, Int>> { it.second }
                    .thenBy { normalize(it.first.label) }
            )
            .map { it.first }
            .toList()
    }

    private fun normalize(value: String): String =
        value.trim().lowercase().replace(Regex("\\s+"), " ")
}
