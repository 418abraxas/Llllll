package dev.findthink.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Bundle

class MainActivity : Activity() {
    private var homeScreen: HomeScreen? = null
    private var thinkScreen: ThinkScreen? = null
    private val aiClient = AiClient()
    private var launchableApps: List<LaunchableApp> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        homeScreen = HomeScreen(this, ::launchApp, ::searchStore, ::openThink)
        setContentView(homeScreen!!.root)
    }

    override fun onStart() {
        super.onStart()
        launchableApps = Find.loadLaunchableApps(packageManager)
        homeScreen?.showApps(launchableApps, Settings.readUsage(this))
    }

    override fun onStop() {
        homeScreen?.clearTransientState()
        thinkScreen?.clear()
        thinkScreen = null
        homeScreen?.root?.let { setContentView(it) }
        launchableApps = emptyList()
        aiClient.cancel(clearPayload = true)
        super.onStop()
    }

    private fun launchApp(app: LaunchableApp) {
        Settings.recordLaunch(this, app.packageName)
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: PackageManager.NameNotFoundException) {
            // The application may have been uninstalled since the index was built.
        } catch (_: SecurityException) {
            // The target may no longer be launchable.
        }
    }


    private fun searchStore(query: String) {
        if (query.isBlank()) return
        val marketUri = Uri.parse("market://search?q=${Uri.encode(query)}&c=apps")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri))
        } catch (_: android.content.ActivityNotFoundException) {
            val webUri = Uri.parse(
                "https://play.google.com/store/search?q=${Uri.encode(query)}&c=apps"
            )
            startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    private fun openThink() {
        homeScreen?.clearTransientState()
        launchableApps = emptyList()
        thinkScreen = ThinkScreen(this, aiClient, ::closeThink)
        setContentView(thinkScreen!!.root)
    }

    private fun closeThink() {
        thinkScreen?.clear()
        thinkScreen = null
        homeScreen?.root?.let { setContentView(it) }
        launchableApps = Find.loadLaunchableApps(packageManager)
        homeScreen?.showApps(launchableApps, Settings.readUsage(this))
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (thinkScreen != null) closeThink() else super.onBackPressed()
    }
}
