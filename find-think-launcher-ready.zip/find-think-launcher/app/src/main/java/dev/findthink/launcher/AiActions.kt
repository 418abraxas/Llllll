package dev.findthink.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject
import java.net.URI

sealed interface ProposedAction {
    data class OpenApp(val packageName: String) : ProposedAction
    data class SearchStore(val query: String) : ProposedAction
    data class SetTimer(val seconds: Int, val label: String = "") : ProposedAction
    data class OpenUrl(val url: String) : ProposedAction
}

object AiActions {
    private const val START_MARKER = "[[ACTION]]"
    private const val END_MARKER = "[[/ACTION]]"
    private const val MAX_PROPOSALS = 4

    /** Extract only explicitly delimited JSON proposals. Unrecognized or invalid data is ignored. */
    fun parseProposals(text: String): List<ProposedAction> {
        val actions = ArrayList<ProposedAction>(MAX_PROPOSALS)
        var cursor = 0

        while (actions.size < MAX_PROPOSALS) {
            val start = text.indexOf(START_MARKER, cursor)
            if (start < 0) break
            val jsonStart = start + START_MARKER.length
            val end = text.indexOf(END_MARKER, jsonStart)
            if (end < 0) break

            val proposal = text.substring(jsonStart, end)
            val action = try {
                val json = JSONObject(proposal)
                when (json.optString("type")) {
                    "open_app" -> ProposedAction.OpenApp(json.optString("package_name"))
                    "search_store" -> ProposedAction.SearchStore(json.optString("query"))
                    "set_timer" -> ProposedAction.SetTimer(
                        json.optInt("seconds", -1), json.optString("label")
                    )
                    "open_url" -> ProposedAction.OpenUrl(json.optString("url"))
                    else -> null
                }
            } catch (_: Exception) {
                null
            }

            if (action != null && validate(action)) actions.add(action)
            cursor = end + END_MARKER.length
        }
        return actions
    }

    fun removeMarkers(text: String): String {
        val visible = StringBuilder(text.length)
        var cursor = 0
        while (cursor < text.length) {
            val start = text.indexOf(START_MARKER, cursor)
            if (start < 0) {
                visible.append(text, cursor, text.length)
                break
            }
            visible.append(text, cursor, start)
            val end = text.indexOf(END_MARKER, start + START_MARKER.length)
            if (end < 0) {
                visible.append(text, start + START_MARKER.length, text.length)
                break
            }
            cursor = end + END_MARKER.length
        }
        return visible.toString().trim()
    }

    fun validate(action: ProposedAction): Boolean = when (action) {
        is ProposedAction.OpenApp ->
            action.packageName.matches(Regex("""[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+""")) &&
                action.packageName.length <= 255
        is ProposedAction.SearchStore ->
            action.query.isNotBlank() && action.query.length <= 200 &&
                action.query.none { it.isISOControl() }
        is ProposedAction.SetTimer ->
            action.seconds in 1..86_400 && action.label.length <= 80 &&
                action.label.none { it.isISOControl() }
        is ProposedAction.OpenUrl -> try {
            val uri = URI(action.url)
            (uri.scheme.equals("https", ignoreCase = true) ||
                uri.scheme.equals("http", ignoreCase = true)) &&
                !uri.host.isNullOrBlank() && uri.rawUserInfo == null &&
                uri.fragment == null && action.url.length <= 2_048
        } catch (_: Exception) {
            false
        }
    }

    fun describe(action: ProposedAction): String = when (action) {
        is ProposedAction.OpenApp -> "Open app ${action.packageName}"
        is ProposedAction.SearchStore -> "Search Play Store for ${action.query}"
        is ProposedAction.SetTimer -> "Set a ${action.seconds}-second timer" +
            if (action.label.isBlank()) "" else " (${action.label})"
        is ProposedAction.OpenUrl -> "Open ${action.url}"
    }

    fun execute(context: Context, action: ProposedAction): Boolean {
        if (!validate(action)) return false
        return try {
            when (action) {
                is ProposedAction.OpenApp -> {
                    val launch = context.packageManager.getLaunchIntentForPackage(action.packageName)
                        ?: return false
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                is ProposedAction.SearchStore -> {
                    val market = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://search?q=${Uri.encode(action.query)}&c=apps")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(market)
                    } catch (_: android.content.ActivityNotFoundException) {
                        val web = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/search?q=${Uri.encode(action.query)}&c=apps")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(web)
                    }
                }
                is ProposedAction.SetTimer -> {
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, action.seconds)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    if (action.label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, action.label)
                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                is ProposedAction.OpenUrl -> {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(action.url))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
