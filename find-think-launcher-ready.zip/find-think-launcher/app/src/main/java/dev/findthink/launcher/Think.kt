package dev.findthink.launcher

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ThinkScreen(
    private val context: Context,
    private val client: AiClient,
    private val onBack: () -> Unit
) {
    val root: View
    private val transcript = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(12, 12, 12, 12)
    }
    private val scroll = ScrollView(context)
    private val prompt = EditText(context)
    private val sendButton = Button(context).apply { text = "Send" }
    private val status = TextView(context).apply {
        setTextColor(0xFFBBBBBB.toInt())
        textSize = 12f
    }
    private val pendingActions = ArrayDeque<ProposedAction>()
    private var activeDialog: AlertDialog? = null
    private var cleared = false

    init {
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.BLACK)
        }
        val top = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val back = Button(context).apply {
            text = "←"
            setOnClickListener { client.cancel(); onBack() }
        }
        val title = TextView(context).apply {
            text = "Think"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(12, 0, 0, 0)
        }
        val settings = Button(context).apply {
            text = "Settings"
            setOnClickListener { showSettings() }
        }
        top.addView(back)
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(settings)

        scroll.addView(transcript)
        prompt.hint = "Ask anything…"
        prompt.setTextColor(Color.WHITE)
        prompt.setHintTextColor(0xFFAAAAAA.toInt())
        prompt.setPadding(12, 12, 12, 12)
        prompt.minLines = 1
        prompt.maxLines = 4
        prompt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE

        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val payload = Button(context).apply {
            text = "Payload"
            setOnClickListener { showPayload() }
        }
        bottom.addView(prompt, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(sendButton)
        column.addView(top)
        column.addView(status)
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        column.addView(bottom)
        column.addView(payload)
        root = column

        sendButton.setOnClickListener { send() }
        append("System", "Think is ready. Configure your endpoint and API key in Settings.")
    }

    private fun send() {
        val query = prompt.text?.toString()?.trim().orEmpty()
        if (query.isEmpty()) return
        val config = AiSettings.read(context)
        if (config.endpoint.isBlank() || config.model.isBlank() || config.apiKey.isBlank()) {
            showSettings()
            status.text = "Configure endpoint, model and API key first."
            return
        }

        prompt.text?.clear()
        append("You", query)
        sendButton.isEnabled = false
        status.text = "Connecting…"
        val answer = StringBuilder()
        append("AI", "")
        client.send(
            config = config,
            query = query,
            onDelta = { delta ->
                answer.append(delta)
                updateLastAssistant(answer.toString())
                status.text = "Streaming…"
            },
            onComplete = { error ->
                sendButton.isEnabled = true
                status.text = error ?: "Complete"
                updateLastAssistant(AiActions.removeMarkers(answer.toString()))
                if (error != null) append("Error", error)
                if (error == null) {
                    pendingActions.clear()
                    pendingActions.addAll(AiActions.parseProposals(answer.toString()))
                    showNextActionConfirmation()
                }
            }
        )
    }

    private fun showNextActionConfirmation() {
        if (cleared || pendingActions.isEmpty()) return
        val action = pendingActions.removeFirst()
        val dialog = AlertDialog.Builder(context)
            .setTitle("Confirm action")
            .setMessage(AiActions.describe(action))
            .setNegativeButton("Cancel remaining") { _, _ -> pendingActions.clear() }
            .setPositiveButton("Confirm") { _, _ ->
                val executed = AiActions.execute(context, action)
                status.text = if (executed) "Action launched." else "Action could not be launched."
                root.post { showNextActionConfirmation() }
            }
            .create()
        dialog.setOnCancelListener { pendingActions.clear() }
        showManagedDialog(dialog)
    }

    private fun append(who: String, text: String) {
        val label = TextView(context).apply {
            this.text = if (text.isEmpty()) "$who\n" else "$who\n$text"
            textSize = 15f
            setTextColor(if (who == "You") 0xFFB8D8FF.toInt() else Color.WHITE)
            setPadding(8, 10, 8, 10)
        }
        transcript.addView(label)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateLastAssistant(value: String) {
        if (transcript.childCount == 0) return
        val last = transcript.getChildAt(transcript.childCount - 1) as? TextView ?: return
        last.text = "AI\n$value"
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showPayload() {
        val bytes = client.lastPayloadBytes()
        val exact = bytes?.toString(Charsets.UTF_8)
        val dialog = AlertDialog.Builder(context)
            .setTitle("Last payload sent")
            .setMessage(exact ?: "No request has been sent in this Think session.")
            .setPositiveButton("Close", null)
            .create()
        showManagedDialog(dialog)
    }

    private fun showSettings() {
        val current = AiSettings.read(context)
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
            EditText(context).apply {
                this.hint = hint
                setText(value)
                inputType = type
            }
        val endpoint = field("Chat completions endpoint URL", current.endpoint)
        val model = field("Model", current.model)
        val key = field("API key", current.apiKey, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(endpoint)
        box.addView(model)
        box.addView(key)
        val dialog = AlertDialog.Builder(context)
            .setTitle("AI connection")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                try {
                    AiSettings.write(
                        context,
                        endpoint.text.toString().trim(),
                        model.text.toString().trim(),
                        key.text.toString()
                    )
                    status.text = "Settings saved on this device."
                } catch (_: Exception) {
                    status.text = "Could not save settings securely on this device."
                }
            }
            .create()
        showManagedDialog(dialog)
    }

    private fun showManagedDialog(dialog: AlertDialog) {
        activeDialog?.dismiss()
        activeDialog = dialog
        dialog.setOnDismissListener {
            if (activeDialog === dialog) activeDialog = null
        }
        dialog.show()
    }

    fun clear() {
        cleared = true
        pendingActions.clear()
        activeDialog?.dismiss()
        activeDialog = null
        client.cancel(clearPayload = true)
        transcript.removeAllViews()
        prompt.text?.clear()
        status.text = ""
    }
}
