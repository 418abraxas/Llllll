package dev.findthink.launcher

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URI
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean

data class AiConfig(
    val endpoint: String,
    val model: String,
    val apiKey: String
)

class AiClient {
    private class ActiveRequest {
        val cancelled = AtomicBoolean(false)
        @Volatile var connection: HttpURLConnection? = null
        @Volatile var thread: Thread? = null

        fun cancel() {
            cancelled.set(true)
            connection?.disconnect()
            thread?.interrupt()
        }
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var activeRequest: ActiveRequest? = null
    @Volatile private var lastPayload: ByteArray? = null

    fun send(
        config: AiConfig,
        query: String,
        onDelta: (String) -> Unit,
        onComplete: (String?) -> Unit
    ) {
        cancel()
        val request = ActiveRequest()
        activeRequest = request
        val payload = buildPayload(config.model, query)

        val thread = Thread({
            var error: String? = null
            var connection: HttpURLConnection? = null
            try {
                if (request.cancelled.get()) return@Thread

                val endpoint = URI(config.endpoint)
                require(endpoint.scheme.equals("https", ignoreCase = true)) {
                    "Endpoint must use HTTPS to protect the API key."
                }
                require(!endpoint.host.isNullOrBlank() && endpoint.rawUserInfo == null && endpoint.fragment == null) {
                    "Endpoint must be a valid HTTPS URL without embedded credentials or a fragment."
                }

                val openedConnection = (endpoint.toURL().openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    instanceFollowRedirects = false
                    connectTimeout = 15_000
                    readTimeout = 60_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "text/event-stream")
                    setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                }
                connection = openedConnection
                request.connection = openedConnection
                if (request.cancelled.get()) return@Thread

                openedConnection.outputStream.use { it.write(payload) }
                lastPayload = payload.copyOf()
                if (request.cancelled.get()) return@Thread

                val code = openedConnection.responseCode
                if (code !in 200..299) {
                    val detail = readErrorSnippet(openedConnection)
                    error = when {
                        code in 300..399 -> "HTTP $code (redirects are disabled for credential safety)."
                        detail.isBlank() -> "HTTP $code"
                        else -> "HTTP $code: $detail"
                    }
                } else {
                    BufferedReader(
                        InputStreamReader(openedConnection.inputStream, StandardCharsets.UTF_8)
                    ).use { reader ->
                        while (!request.cancelled.get()) {
                            val line = reader.readLine() ?: break
                            if (!line.startsWith("data:")) continue
                            val data = line.removePrefix("data:").trim()
                            if (data == "[DONE]") break
                            val delta = extractDelta(data)
                            if (delta.isNotEmpty()) {
                                main.post {
                                    if (!request.cancelled.get() && activeRequest === request) {
                                        onDelta(delta)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                if (!request.cancelled.get()) {
                    error = e.message ?: e.javaClass.simpleName
                }
            } finally {
                connection?.disconnect()
                request.connection = null
                if (!request.cancelled.get()) {
                    val result = error
                    main.post {
                        if (!request.cancelled.get() && activeRequest === request) {
                            activeRequest = null
                            onComplete(result)
                        }
                    }
                }
            }
        }, "FindThink-AI-request")

        request.thread = thread
        thread.start()
    }

    fun lastPayloadBytes(): ByteArray? = lastPayload?.copyOf()

    /** Stops the active user-initiated request. Clear payload bytes when the Think screen closes. */
    fun cancel(clearPayload: Boolean = false) {
        val request = activeRequest
        activeRequest = null
        request?.cancel()
        if (clearPayload) lastPayload = null
    }

    private fun readErrorSnippet(connection: HttpURLConnection): String {
        val stream = connection.errorStream ?: return ""
        return stream.bufferedReader(StandardCharsets.UTF_8).use { reader ->
            val buffer = CharArray(512)
            val count = reader.read(buffer, 0, buffer.size)
            if (count <= 0) "" else String(buffer, 0, count).trim()
        }
    }

    private fun extractDelta(data: String): String = try {
        val root = JSONObject(data)
        root.optJSONArray("choices")
            ?.optJSONObject(0)
            ?.optJSONObject("delta")
            ?.optString("content")
            .orEmpty()
    } catch (_: Exception) {
        ""
    }

    companion object {
        /** Request content is only the current query; model and streaming are transport settings. */
        fun buildPayload(model: String, query: String): ByteArray {
            return JSONObject()
                .put("model", model)
                .put("stream", true)
                .put("messages", org.json.JSONArray().put(
                    JSONObject().put("role", "user").put("content", query)
                ))
                .toString()
                .toByteArray(StandardCharsets.UTF_8)
        }
    }
}
