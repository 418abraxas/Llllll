package dev.findthink.launcher

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeScreen(
    context: Context,
    private val onLaunch: (LaunchableApp) -> Unit,
    private val onStoreSearch: (String) -> Unit,
    private val onThink: () -> Unit
) {
    val root: View
    private val search = EditText(context)
    private val results = RecyclerView(context)
    private val message = TextView(context)
    private val adapter = AppAdapter(onLaunch)
    private var apps: List<LaunchableApp> = emptyList()
    private var usage: Map<String, Int> = emptyMap()

    init {
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val heading = TextView(context).apply {
            text = "Find / Think"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 32, 0, 20)
        }

        search.apply {
            hint = "Find an app…"
            textSize = 18f
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(0xFFAAAAAA.toInt())
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFF252525.toInt())
        }

        val think = TextView(context).apply {
            text = "THINK  →"
            textSize = 14f
            gravity = Gravity.END
            setTextColor(0xFFBDBDBD.toInt())
            setPadding(12, 12, 12, 12)
            setOnClickListener { onThink() }
        }

        message.apply {
            textSize = 13f
            setTextColor(0xFFBBBBBB.toInt())
            setPadding(8, 8, 8, 8)
            visibility = View.GONE
        }

        results.layoutManager = LinearLayoutManager(context)
        results.adapter = adapter
        results.setHasFixedSize(true)
        results.setBackgroundColor(Color.TRANSPARENT)

        column.addView(heading, matchWrap())
        column.addView(search, matchWrap())
        column.addView(think, matchWrap())
        column.addView(message, matchWrap())
        column.addView(results, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root = column

        search.addTextChangedListener(SimpleTextWatcher { query ->
            render(query)
        })
    }

    fun showApps(applications: List<LaunchableApp>, learnedUsage: Map<String, Int>) {
        apps = applications
        usage = learnedUsage
        render(search.text?.toString().orEmpty())
    }

    fun showMessage(value: String) {
        message.text = value
        message.visibility = View.VISIBLE
    }

    fun clearTransientState() {
        search.text?.clear()
        adapter.submit(emptyList())
        results.removeAllViews()
        apps = emptyList()
        usage = emptyMap()
        message.text = ""
        message.setOnClickListener(null)
        message.visibility = View.GONE
    }

    private fun render(query: String) {
        val ranked = Find.rank(query, apps, usage)
        adapter.submit(ranked)
        if (query.isNotBlank() && ranked.isEmpty()) {
            message.text = "Search Play Store for “$query”"
            message.setOnClickListener { onStoreSearch(query) }
            message.visibility = View.VISIBLE
        } else {
            message.setOnClickListener(null)
            message.visibility = View.GONE
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private class AppAdapter(
        private val onLaunch: (LaunchableApp) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.Holder>() {
        private var items: List<LaunchableApp> = emptyList()

        fun submit(next: List<LaunchableApp>) {
            items = next
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = TextView(parent.context).apply {
                textSize = 17f
                setTextColor(Color.WHITE)
                setPadding(12, 12, 12, 12)
                isClickable = true
                isFocusable = true
            }
            return Holder(view)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val app = items[position]
            holder.label.text = app.label
            holder.label.setOnClickListener { onLaunch(app) }
        }

        override fun getItemCount(): Int = items.size

        class Holder(val label: TextView) : RecyclerView.ViewHolder(label)
    }
}


private class SimpleTextWatcher(
    private val onChanged: (String) -> Unit
) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        onChanged(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: Editable?) = Unit
}
