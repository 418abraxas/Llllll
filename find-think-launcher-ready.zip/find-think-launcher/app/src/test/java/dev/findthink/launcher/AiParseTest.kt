package dev.findthink.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiParseTest {
    @Test fun parsesOnlyWhitelistedActionMarkers() {
        val answer = """
            I can do that.
            [[ACTION]]{"type":"set_timer","seconds":300,"label":"Tea"}[[/ACTION]]
            [[ACTION]]{"type":"launch_shell","command":"id"}[[/ACTION]]
        """.trimIndent()
        val actions = AiActions.parseProposals(answer)
        assertEquals(1, actions.size)
        assertTrue(actions.first() is ProposedAction.SetTimer)
    }

    @Test fun malformedMarkersAreIgnored() {
        assertTrue(AiActions.parseProposals("[[ACTION]]not-json[[/ACTION]]").isEmpty())
    }

    @Test fun nestedJsonStringsAreParsedAndHiddenFromTranscript() {
        val proposal = "[[ACTION]]{\"type\":\"set_timer\",\"seconds\":60,\"label\":\"Tea } time\"}[[/ACTION]]"
        val actions = AiActions.parseProposals(proposal)
        assertEquals(1, actions.size)
        assertEquals("", AiActions.removeMarkers(proposal))
    }

    @Test fun timerRangeIsValidated() {
        assertTrue(AiActions.validate(ProposedAction.SetTimer(60)))
        assertFalse(AiActions.validate(ProposedAction.SetTimer(0)))
        assertFalse(AiActions.validate(ProposedAction.SetTimer(86_401)))
    }

    @Test fun urlsRequireHttpOrHttpsHost() {
        assertTrue(AiActions.validate(ProposedAction.OpenUrl("https://example.com")))
        assertFalse(AiActions.validate(ProposedAction.OpenUrl("javascript:alert(1)")))
        assertFalse(AiActions.validate(ProposedAction.OpenUrl("file:///etc/passwd")))
        assertFalse(AiActions.validate(ProposedAction.OpenUrl("https:///missing-host")))
    }

    @Test fun emptyArgumentsAreRejected() {
        assertFalse(AiActions.validate(ProposedAction.OpenApp("")))
        assertFalse(AiActions.validate(ProposedAction.SearchStore(" ")))
    }

    @Test fun unknownActionNameIsRejected() {
        assertTrue(AiActions.parseProposals(
            """[[ACTION]]{"type":"delete_files","path":"/"}[[/ACTION]]"""
        ).isEmpty())
    }
}
