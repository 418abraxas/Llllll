package dev.findthink.launcher

import org.junit.Assert.assertEquals
import org.junit.Test

class ScorerTest {
    private val apps = listOf(
        LaunchableApp("YouTube", "com.example.youtube", "Main"),
        LaunchableApp("YouTube Music", "com.example.music", "Main"),
        LaunchableApp("Google Maps", "com.example.maps", "Main"),
        LaunchableApp("Maps", "com.example.maps2", "Main")
    )

    @Test fun exactMatchRanksFirst() {
        assertEquals("Maps", Find.rank("Maps", apps).first().label)
    }

    @Test fun prefixMatchIsFound() {
        val labels = Find.rank("you", apps).map { it.label }
        assertEquals(listOf("YouTube", "YouTube Music"), labels)
    }

    @Test fun matchingIsCaseInsensitive() {
        assertEquals(2, Find.rank("YOUTUBE", apps).size)
    }

    @Test fun emptyQueryReturnsNoResults() {
        assertEquals(emptyList<LaunchableApp>(), Find.rank("  ", apps))
    }

    @Test fun noMatchReturnsNoResults() {
        assertEquals(emptyList<LaunchableApp>(), Find.rank("calendar", apps))
    }

    @Test fun learnedUsageBreaksEqualMatchClass() {
        val ranked = Find.rank(
            "you",
            apps,
            mapOf("com.example.music" to 100)
        )
        assertEquals("YouTube Music", ranked.first().label)
    }

    @Test fun rankingIsDeterministic() {
        assertEquals(Find.rank("you", apps), Find.rank("you", apps))
    }
}
