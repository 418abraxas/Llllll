# Find / Think Launcher

A minimal, local-first Android HOME launcher. **Find** searches installed apps locally. **Think** is an optional, user-configured AI chat with streaming and confirmed action proposals.

## Current implementation

- One Android application module and eight production Kotlin source files.
- One HOME activity with transparent wallpaper-backed home surface; no services, receivers, providers, or extra processes declared.
- Local launchable-app discovery, matching, learned launch-count ranking, and app launch.
- Play Store search hand-off when local Find returns no match.
- Think screen with a BYOK HTTPS Chat Completions request, Server-Sent Events streaming, Android Keystore AES-GCM key encryption, and a last-request-body viewer.
- Query text is the only message content sent by default; application labels and chat history are not included.
- Four action proposal types (`open_app`, `search_store`, `set_timer`, `open_url`) are parsed from explicit `[[ACTION]]...[[/ACTION]]` markers and require individual confirmation.
- Unit tests for local ranking and action parsing/validation.

The action protocol is deliberately a lightweight text-marker implementation, not provider-native function calling. The model must produce the documented marker syntax for an action proposal to be recognized.

## Build prerequisites

- JDK 17 or newer.
- Android SDK Platform 35.
- Android SDK Build-Tools 35.0.0.
- Network access the first time `gradlew` runs, so it can download the pinned Gradle 8.11.1 distribution and the Gradle plugins/dependencies.
- Android SDK location available through `ANDROID_HOME`, `ANDROID_SDK_ROOT`, or `local.properties`.

The project uses Android Gradle Plugin 8.9.1, Gradle 8.11.1, Kotlin Gradle Plugin 2.1.20, compile SDK 35, build tools 35.0.0, min SDK 26, and Java/Kotlin bytecode target 17.

## Build commands

Run the complete build and unit-test verification with one command.

macOS / Linux:

```bash
./gradlew build
```

Windows:

```bat
gradlew.bat build
```

For focused tasks, use `./gradlew testDebugUnitTest` or `./gradlew assembleDebug` (Windows: `gradlew.bat` instead of `./gradlew`).

The self-bootstrapping `gradlew` launcher downloads Gradle 8.11.1 into the user's Gradle cache and verifies the official SHA-256 before execution. It does not require a system-wide Gradle installation. The project includes the corresponding `gradle-wrapper.properties`; the launcher is a small repository bootstrap script rather than the official Wrapper JAR because that JAR could not be fetched in the generation environment.

If Android Studio is installed, open this project once and install **Android SDK Platform 35** and **Android SDK Build-Tools 35.0.0** from SDK Manager. Android Studio can write `local.properties` for the SDK path. Do not commit `local.properties`.

If Android command-line tools are already installed, the equivalent setup is:

```bash
sdkmanager --licenses
sdkmanager "platforms;android-35" "build-tools;35.0.0"
```

Set `ANDROID_HOME` or `ANDROID_SDK_ROOT`, or copy `local.properties.example` to `local.properties` and set `sdk.dir` to the SDK directory.

## Output

A successful debug build creates:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Tests and status

Run unit tests alone with `./gradlew testDebugUnitTest`. R8 full mode is the AGP 8.0+ default and is not disabled here; the release build enables minification and resource shrinking. The PSS targets are acceptance criteria, not measured results. The project has not yet been compiled or verified on a physical Android device in the generation environment.
