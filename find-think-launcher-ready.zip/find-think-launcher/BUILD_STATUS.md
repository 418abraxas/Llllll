# Build readiness report

## Project-side checks completed

- [x] Gradle and Kotlin plugin versions pinned.
- [x] Gradle 8.11.1 distribution URL and official SHA-256 pinned.
- [x] Self-bootstrapping Unix and Windows build launchers added.
- [x] Android SDK Platform 35 and Build-Tools 35.0.0 selected in the Android module.
- [x] JDK bytecode target set to 17.
- [x] XML files parsed successfully.
- [x] Manifest checked: INTERNET only; MAIN+LAUNCHER `<queries>`; one HOME activity; no service, receiver, or provider.
- [x] Eight production Kotlin files; each remains below 400 lines.
- [x] Two direct runtime dependencies; JSON parser dependency is test-only.
- [x] Unix bootstrap script passes `bash -n`.
- [x] Pure JDK URL-validation and marker-cleanup snippets compile and run.
- [x] Kotlin syntax scan produced no parser-level diagnostics.

## Environment verification

- Java available: OpenJDK 21.
- System Gradle: not installed.
- Android SDK / `sdkmanager`: not installed in the build environment.
- Network DNS for `services.gradle.org` and `dl.google.com`: unavailable.

## Build attempt

`./gradlew build` was attempted. The self-bootstrap launcher stopped before Gradle could start because the environment could not resolve `services.gradle.org` while downloading the pinned Gradle distribution.

As a result, the following are **not claimed as passed**:

- Gradle project configuration/build.
- JVM unit tests (`ScorerTest`, `AiParseTest`).
- Debug APK generation.
- Release APK generation and R8 execution.
- Device installation, OEM behavior, or PSS measurements.

## To complete on a machine with network and Android SDK

Install Android SDK Platform 35 and Build-Tools 35.0.0, ensure the SDK path is discoverable via `ANDROID_HOME`, `ANDROID_SDK_ROOT`, or `local.properties`, then run:

```bash
./gradlew build
```

Windows:

```bat
gradlew.bat build
```
